package com.user.service;

import java.util.Arrays;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.user.auth.auth_role;
import com.user.auth.auth_user;
import com.user.repository.authRoleRepository;
import com.user.repository.authUserRepository;

@Service
public class UserServiceImpelement implements UserService {

	@Autowired
	BCryptPasswordEncoder encoder;
	@Autowired
	authRoleRepository roleRepository;
	@Autowired
	authUserRepository userRepository;
	
	@Override
	public void saveUser(auth_user user) {
		user.setPassword(encoder.encode(user.getPassword()));
		user.setStatus("VERIFIED");
		auth_role userRole = roleRepository.findByRole("USER");
		user.setRoles(new HashSet<auth_role>(Arrays.asList(userRole)));
		userRepository.save(user);
	}

	@Override
	public boolean isUserInDB(auth_user user) {
		
		return false;
	}

}
