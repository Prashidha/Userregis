package com.user.service;

import com.user.auth.auth_user;

public interface UserService {
	
	public void saveUser(auth_user user);
	
	public boolean isUserInDB(auth_user user);
	
}
